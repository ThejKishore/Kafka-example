package com.example.demo.kafka.service;


import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Component
public class Listener {

    private static final Logger log = LoggerFactory.getLogger(Listener.class);

    @KafkaListener(topics = "test" , groupId = "test-grp-1" , concurrency = "3")
    public void listen(ConsumerRecord<String,String> record, Acknowledgment acknowledgment){
        log.info(" data recieved Value : {}  Key : {}  Partition: {}  Offset : {} ", record.value()  , record.key() , record.partition() , record.offset());
        acknowledgment.acknowledge();
    }
}
