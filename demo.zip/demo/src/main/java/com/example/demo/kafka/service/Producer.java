package com.example.demo.kafka.service;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

import java.util.concurrent.ExecutionException;

@Component
public class Producer {

    private static final Logger  log = LoggerFactory.getLogger(Producer.class);
    private final KafkaTemplate<String, String> template;

    public Producer(KafkaTemplate<String,String> template){
        this.template = template;
    }

    public boolean publishMessage(String key , String value, String topic) throws ExecutionException, InterruptedException {
        SendResult<String, String> result = template.send(topic, key, value).get();
        return result.getProducerRecord().partition() !=null;
    }



}
