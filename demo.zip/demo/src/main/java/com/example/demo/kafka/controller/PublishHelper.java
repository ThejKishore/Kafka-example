package com.example.demo.kafka.controller;


import com.example.demo.kafka.service.Producer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.ExecutionException;

@RestController
public class PublishHelper {

    private static final Logger log = LoggerFactory.getLogger(PublishHelper.class);

    private final Producer producer;

    public PublishHelper(Producer producer){
        this.producer = producer;
    }


    @PostMapping(value = "/publish" , produces = MediaType.APPLICATION_JSON_VALUE , consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> publish(@RequestBody KafkaData kafkaData) throws ExecutionException, InterruptedException {
        log.info("incoming message {} ", kafkaData);
        boolean response = this.producer.publishMessage(kafkaData.getKey(),  kafkaData.getValue() , kafkaData.getTopic());
        return ResponseEntity.ok(String.format(" Message published successfully %b ",response));
    }

}
